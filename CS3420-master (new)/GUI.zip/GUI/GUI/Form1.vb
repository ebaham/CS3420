﻿Public Class Login
    Private Sub OK_Click(sender As Object, e As EventArgs) Handles OK.Click
        If Username.Text = "admin" And Password.Text = "admin" Then
            Admin.Show()
        Else
            If Username.Text = "student" And Password.Text = "student" Then
                Student.Show()
            Else
                MsgBox("Invalid Username And/Or Password!", MsgBoxStyle.Critical, "Error")
            End If
                End If


    End Sub

    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub
End Class