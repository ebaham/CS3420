﻿Public Class Student
    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click
        End
    End Sub
End Class